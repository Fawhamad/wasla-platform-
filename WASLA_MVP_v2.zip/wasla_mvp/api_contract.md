# WASLA API contract – MVP production backlog

Base path: `/api/v1`
Authentication: managed identity provider; API validates signed access tokens. Never accept a role or tenant ID as trusted merely because the browser sends it.

## Identity and organizations
- `GET /me` – current user and permitted organizations/roles.
- `POST /organizations` – create supplier or retailer organization (admin approval workflow).
- `GET /organizations/{id}` – allowed members only.
- `POST /organizations/{id}/members` – invite/add member with role validation.

## Catalog and pricing
- `GET /catalog?category=&q=&supplier_id=` – retailer-visible active products and applicable price.
- `POST /supplier/products` – supplier staff create product for their own supplier organization.
- `PATCH /supplier/products/{id}` – update own product only.
- `POST /supplier/price-lists` and `PUT /supplier/price-lists/{id}/items` – supplier pricing.
- `GET /supplier/inventory` – own inventory lots and expiry dates.

## Orders
- `POST /orders` – retailer creates order; server recalculates price and totals.
- `GET /orders` – results scoped to caller's organization and role.
- `GET /orders/{id}` – authorized parties only.
- `POST /orders/{id}/confirm` – supplier/platform confirms availability.
- `POST /orders/{id}/status` – validated state transition; record actor and timestamp.
- `POST /orders/{id}/cancel` – policy-controlled cancellation.

## Fulfillment and finance
- `POST /orders/{id}/assign-delivery` – dispatcher assigns driver.
- `POST /deliveries/{id}/proof` – driver submits proof of delivery.
- `POST /invoices` – generate invoice from confirmed delivered quantities.
- `POST /invoices/{id}/payments` – record payment/collection.
- `GET /reports/sales` – scoped reports; platform-wide only for platform admin.

## Mandatory server-side rules
1. Derive user and organization membership from verified token/session; ignore client-supplied owner IDs.
2. Recalculate unit prices, discounts, taxes, delivery fee and totals on server.
3. Prevent negative stock and overselling in a database transaction.
4. Track lot/expiry and allocate FEFO for applicable products.
5. Preserve order item name/SKU/price snapshots after order submission.
6. Enforce legal order status transitions and append audit log entries.
7. Apply rate limits, input validation, CSRF protections where cookie sessions are used, secure headers and encrypted backups.
8. Do not store card data; use a compliant payment provider if online payment is introduced.
