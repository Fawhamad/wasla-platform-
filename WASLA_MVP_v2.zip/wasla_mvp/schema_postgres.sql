-- WASLA production foundation: PostgreSQL schema draft
-- Tenant isolation: every supplier/retailer-owned row carries tenant_id where applicable.
-- Apply only after review; production deployment still requires migrations, RLS policies,
-- authentication provider configuration, backups, monitoring and security testing.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE user_role AS ENUM ('platform_admin','supplier_admin','supplier_staff','retailer_owner','retailer_staff','driver');
CREATE TYPE order_status AS ENUM ('draft','submitted','confirmed','preparing','ready','out_for_delivery','delivered','cancelled','partially_delivered');
CREATE TYPE payment_status AS ENUM ('unpaid','partially_paid','paid','refunded');
CREATE TYPE fulfillment_mode AS ENUM ('supplier_direct','platform_delivery','cross_dock');

CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_type text NOT NULL CHECK (org_type IN ('supplier','retailer','platform')),
  legal_name text NOT NULL,
  display_name text NOT NULL,
  tax_number text,
  phone text,
  email text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_subject text UNIQUE NOT NULL, -- ID from managed identity provider; never store plaintext passwords
  full_name text NOT NULL,
  phone text,
  email text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE organization_memberships (
  organization_id uuid NOT NULL REFERENCES organizations(id),
  user_id uuid NOT NULL REFERENCES app_users(id),
  role user_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id,user_id,role)
);

CREATE TABLE addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  label text,
  governorate text,
  city text,
  district text,
  street_address text NOT NULL,
  building_details text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar text NOT NULL,
  name_en text,
  parent_id uuid REFERENCES categories(id),
  is_active boolean NOT NULL DEFAULT true
);

CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_org_id uuid NOT NULL REFERENCES organizations(id),
  category_id uuid REFERENCES categories(id),
  sku text,
  barcode text,
  name_ar text NOT NULL,
  name_en text,
  description text,
  base_unit text NOT NULL DEFAULT 'carton',
  units_per_case numeric(12,3),
  brand text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (supplier_org_id, sku)
);

CREATE TABLE product_packs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id),
  pack_name text NOT NULL,
  unit_quantity numeric(12,3) NOT NULL CHECK (unit_quantity > 0),
  barcode text,
  is_default boolean NOT NULL DEFAULT false
);

CREATE TABLE price_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_org_id uuid NOT NULL REFERENCES organizations(id),
  retailer_org_id uuid REFERENCES organizations(id), -- NULL means supplier's general list
  currency char(3) NOT NULL DEFAULT 'EGP',
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE TABLE price_list_items (
  price_list_id uuid NOT NULL REFERENCES price_lists(id) ON DELETE CASCADE,
  product_pack_id uuid NOT NULL REFERENCES product_packs(id),
  unit_price numeric(14,2) NOT NULL CHECK (unit_price >= 0),
  min_quantity numeric(12,3) NOT NULL DEFAULT 1 CHECK (min_quantity > 0),
  PRIMARY KEY (price_list_id,product_pack_id,min_quantity)
);

CREATE TABLE inventory_lots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_org_id uuid NOT NULL REFERENCES organizations(id),
  product_pack_id uuid NOT NULL REFERENCES product_packs(id),
  lot_code text NOT NULL,
  expiry_date date,
  received_at timestamptz NOT NULL DEFAULT now(),
  quantity_available numeric(14,3) NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
  storage_location text,
  UNIQUE (supplier_org_id,product_pack_id,lot_code)
);

CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  retailer_org_id uuid NOT NULL REFERENCES organizations(id),
  supplier_org_id uuid NOT NULL REFERENCES organizations(id),
  delivery_address_id uuid REFERENCES addresses(id),
  status order_status NOT NULL DEFAULT 'submitted',
  fulfillment fulfillment_mode NOT NULL DEFAULT 'platform_delivery',
  currency char(3) NOT NULL DEFAULT 'EGP',
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  discount_total numeric(14,2) NOT NULL DEFAULT 0,
  delivery_fee numeric(14,2) NOT NULL DEFAULT 0,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  grand_total numeric(14,2) NOT NULL DEFAULT 0,
  payment_status payment_status NOT NULL DEFAULT 'unpaid',
  notes text,
  created_by uuid NOT NULL REFERENCES app_users(id),
  submitted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  product_pack_id uuid NOT NULL REFERENCES product_packs(id),
  product_name_snapshot text NOT NULL,
  sku_snapshot text,
  quantity numeric(12,3) NOT NULL CHECK (quantity > 0),
  unit_price numeric(14,2) NOT NULL CHECK (unit_price >= 0),
  discount_amount numeric(14,2) NOT NULL DEFAULT 0,
  line_total numeric(14,2) NOT NULL CHECK (line_total >= 0)
);

CREATE TABLE deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id),
  driver_user_id uuid REFERENCES app_users(id),
  delivery_status text NOT NULL DEFAULT 'assigned',
  planned_date date,
  delivered_at timestamptz,
  proof_of_delivery_url text,
  recipient_name text,
  failure_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL UNIQUE REFERENCES orders(id),
  invoice_number text UNIQUE NOT NULL,
  issued_at timestamptz NOT NULL DEFAULT now(),
  due_at timestamptz,
  subtotal numeric(14,2) NOT NULL,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  grand_total numeric(14,2) NOT NULL,
  payment_status payment_status NOT NULL DEFAULT 'unpaid'
);

CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id),
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  method text NOT NULL CHECK (method IN ('cash','bank_transfer','wallet','online','other')),
  reference_number text,
  received_by uuid REFERENCES app_users(id),
  received_at timestamptz NOT NULL DEFAULT now(),
  notes text
);

CREATE TABLE audit_log (
  id bigserial PRIMARY KEY,
  actor_user_id uuid REFERENCES app_users(id),
  organization_id uuid REFERENCES organizations(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_products_supplier_active ON products(supplier_org_id,is_active);
CREATE INDEX idx_orders_retailer_created ON orders(retailer_org_id,created_at DESC);
CREATE INDEX idx_orders_supplier_created ON orders(supplier_org_id,created_at DESC);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_lots_expiry ON inventory_lots(supplier_org_id,expiry_date);
CREATE INDEX idx_memberships_user ON organization_memberships(user_id);

-- SECURITY TODO (mandatory before production):
-- 1) Enable RLS on every tenant-owned table.
-- 2) Set request-scoped organization/user claims from verified server-side auth.
-- 3) Policies must verify membership and role; never trust organization_id from browser input.
-- 4) Platform admin access must be explicit and audited.
-- 5) Add immutable order/invoice snapshots and stock movement ledger before live inventory.
